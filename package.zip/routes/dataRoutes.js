const express = require('express')
const {
    getSensor,
    getSensorAsc,
    getSensorOne,
    ispu,
    // iot,
} = require('../controller/dataSensorControler.js')

const router = express.Router()

router.get('/data', getSensor)
router.get('/asc', getSensorAsc)
router.get('/one', getSensorOne)
router.get('/ispu', ispu)
// router.get('/iot', iot);

module.exports = router
